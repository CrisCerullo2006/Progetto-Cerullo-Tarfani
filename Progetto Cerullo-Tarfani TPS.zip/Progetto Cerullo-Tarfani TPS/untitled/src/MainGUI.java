import javax.swing.*;
import java.awt.*;
import java.security.SecureRandom;

public class MainGUI extends JFrame {
    private Player player;
    private Mondo mondo;
    private Nemico nemicoAttuale;
    private int indiceNemico = 0;
    private SecureRandom random = new SecureRandom();

    private JTextArea consoleArea;
    private JLabel lblVitaPlayer, lblVitaNemico, lblPozioni, lblProgresso;
    private JButton btnAttacca, btnPozione;

    public MainGUI() {
        faseIniziale();
        setupFinestra();
        aggiornaUI();
    }

    private void faseIniziale() {
        // 1. Scelta Classe
        String[] opzioniClasse = {"Guerriero", "Mago", "Ladro"};
        int sceltaClasse = JOptionPane.showOptionDialog(null, "Scegli la tua Classe:", "Creazione Personaggio",
                JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, opzioniClasse, opzioniClasse[0]);

        // Se l'utente chiude la finestra, assegniamo Guerriero di default (indice 0)
        if (sceltaClasse < 0) sceltaClasse = 0;
        Classe classeSelezionata = Classe.values()[sceltaClasse];

        // 2. Scelta Mondo
        String[] opzioniMondo = {"Cimitero Dimenticato", "Montagna del Drago"};
        int sceltaMondo = JOptionPane.showOptionDialog(null, "Scegli il Mondo da visitare:", "Scelta Mondo",
                JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, opzioniMondo, opzioniMondo[0]);

        if (sceltaMondo < 0) sceltaMondo = 0;
        mondo = new Mondo(sceltaMondo);

        // 3. Generazione Arma (Semplificata per test)
        Arma armaTrovata = new Arma("Spada Iniziale", "Guerriero", 10);

        // 4. CREAZIONE PLAYER (Assicuriamoci che avvenga DOPO le scelte)
        this.player = new Player(classeSelezionata, armaTrovata);

        // 5. Caricamento primo nemico
        this.nemicoAttuale = mondo.listaNemici.get(0);
    }
    private void setupFinestra() {
        setTitle("RPG - " + mondo.nome);
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel panelStatus = new JPanel(new GridLayout(1, 4));
        lblVitaPlayer = new JLabel("", SwingConstants.CENTER);
        lblPozioni = new JLabel("", SwingConstants.CENTER);
        lblProgresso = new JLabel("", SwingConstants.CENTER);
        lblVitaNemico = new JLabel("", SwingConstants.CENTER);

        panelStatus.add(lblVitaPlayer);
        panelStatus.add(lblPozioni);
        panelStatus.add(lblProgresso);
        panelStatus.add(lblVitaNemico);
        add(panelStatus, BorderLayout.NORTH);

        consoleArea = new JTextArea();
        consoleArea.setEditable(false);
        consoleArea.setBackground(Color.BLACK);
        consoleArea.setForeground(Color.GREEN); // Fa molto "terminale" da hacker
        consoleArea.setFont(new Font("Monospaced", Font.BOLD, 13));
        add(new JScrollPane(consoleArea), BorderLayout.CENTER);

        JPanel panelBottoni = new JPanel();
        btnAttacca = new JButton("Attacca (D20)");
        btnPozione = new JButton("Usa Pozione");
        panelBottoni.add(btnAttacca);
        panelBottoni.add(btnPozione);
        add(panelBottoni, BorderLayout.SOUTH);

        btnAttacca.addActionListener(e -> turnoGiocatore());
        btnPozione.addActionListener(e -> usaPozione());

        scrivi("BENVENUTO VIANDANTE...");
        scrivi("Lore: " + mondo.lore);
        scrivi("Stai affrontando: " + nemicoAttuale.nome);
    }

    private void turnoGiocatore() {
        int dado = random.nextInt(20) + 1;
        int dannoFinale = 0;

        scrivi("\n--- TUO TURNO ---");
        if (dado == 1) {
            scrivi("Risultato: 1. MISS ! Non colpisci il nemico.");
        } else if (dado == 20) {
            dannoFinale = 40;
            scrivi("Risultato: 20. CRITICAL HIT ! Infliggi 40 danni!");
        } else {
            dannoFinale = player.calcolaDanno(dado);
            scrivi("Risultato: " + dado + ". Infliggi " + dannoFinale + " danni.");
        }

        nemicoAttuale.hp -= dannoFinale;

        if (nemicoAttuale.hp <= 0) {
            gestisciVittoriaNemico();
        } else {
            turnoNemico();
        }
        aggiornaUI();
    }

    private void turnoNemico() {
        scrivi("--- TURNO NEMICO ---");
        int dannoSubito = nemicoAttuale.danno - (player.classe.difesa / 5);
        if(dannoSubito <= 0) dannoSubito = 1;

        player.hpAttuali -= dannoSubito;
        scrivi(nemicoAttuale.nome + " ti colpisce per " + dannoSubito + " danni.");

        if (player.hpAttuali <= 0) {
            scrivi("\n!!! SEI MORTO !!! GAME OVER.");
            btnAttacca.setEnabled(false);
            btnPozione.setEnabled(false);
        }
    }

    private void gestisciVittoriaNemico() {
        scrivi("Sconfitto " + nemicoAttuale.nome + "!");

        // Recupero vita automatico
        int cura = player.classe.hp * 30 / 100;
        player.cura(cura);
        scrivi("Ti riposi e recuperi " + cura + " HP.");

        // Drop pozione
        if(random.nextInt(100) < 60) {
            player.pozioni++;
            scrivi("Hai trovato una pozione!");
        }

        indiceNemico++;
        if (indiceNemico >= mondo.listaNemici.size()) {
            scrivi("\n*** HAI COMPLETATO IL MONDO! VITTORIA! ***");
            btnAttacca.setEnabled(false);
            btnPozione.setEnabled(false);
        } else {
            nemicoAttuale = mondo.listaNemici.get(indiceNemico);
            scrivi("Nuovo nemico: " + nemicoAttuale.nome);
        }
    }

    private void usaPozione() {
        if (player.pozioni > 0) {
            player.pozioni--;
            int cura = player.classe.hp / 2;
            player.cura(cura);
            scrivi("\nHai usato una pozione! + " + cura + " HP.");
            turnoNemico();
            aggiornaUI();
        } else {
            scrivi("Pozioni finite!");
        }
    }
    private void aggiornaUI() {
        if (player != null && player.classe != null) {
            // Prendiamo i dati direttamente dall'oggetto player appena creato
            int hp = player.hpAttuali;
            int maxHp = player.classe.hp;
            lblVitaPlayer.setText(" Player HP: " + hp + " / " + maxHp);

            lblPozioni.setText(" Pozioni: " + player.pozioni);
            lblProgresso.setText(" Scontro: " + (indiceNemico + 1) + " / 6");

            if (nemicoAttuale != null) {
                lblVitaNemico.setText(" Nemico: " + Math.max(0, nemicoAttuale.hp) + " HP");
            }
        }
    }

    private void scrivi(String testo) {
        consoleArea.append(testo + "\n");
        consoleArea.setCaretPosition(consoleArea.getDocument().getLength());
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainGUI().setVisible(true));
    }
}
public class Arma {
    public String nome;
    public String classeAffine;
    public int bonusDanno;

    public Arma(String nome, String classeAffine, int bonusDanno) {
        this.nome = nome;
        this.classeAffine = classeAffine;
        this.bonusDanno = bonusDanno;
    }
}
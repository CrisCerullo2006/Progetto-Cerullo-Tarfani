public class Player {
    public Classe classe;
    public int hpAttuali;
    public int pozioni;
    public int bonusAffinità = 0;


    public Arma armaEquipaggiata;

    public Player(Classe classeScelta, Arma armaTrovata) {
        this.classe = classeScelta;
        this.hpAttuali = classeScelta.hp;
        this.pozioni = 3;


        this.armaEquipaggiata = armaTrovata;


        if (armaTrovata != null && armaTrovata.classeAffine.equals(classeScelta.nome)) {
            this.bonusAffinità = armaTrovata.bonusDanno;
        }


        System.out.println("Player creato: " + classeScelta.nome + " con " + this.hpAttuali + " HP");
    }

    public int calcolaDanno(int dado) {
        double moltiplicatore = 1.0;
        if (classe == Classe.GUERRIERO) moltiplicatore += (classe.forza * 0.05);
        else if (classe == Classe.MAGO) moltiplicatore += (classe.intelligenza * 0.05);
        else if (classe == Classe.LADRO) moltiplicatore += (classe.destrezza * 0.05);

        return (int) (dado * moltiplicatore) + bonusAffinità;
    }

    public void cura(int quantita) {
        hpAttuali += quantita;
        if (hpAttuali > classe.hp) hpAttuali = classe.hp;
    }
}
public enum Classe {
    // ORDINE: Nome, HP, MP, Forza, Intelligenza, Destrezza, Fortuna, Agilità, Difesa, Arcano, Iniziativa
    GUERRIERO("Guerriero", 150, 20, 18, 5, 10, 8, 10, 15, 2, 5),
    MAGO("Mago", 80, 100, 4, 18, 8, 12, 10, 5, 15, 8),
    LADRO("Ladro", 100, 40, 10, 8, 15, 16, 18, 8, 5, 15);

    public String nome;
    public int hp, mp, forza, intelligenza, destrezza, fortuna, agilita, difesa, arcano, iniziativa;

    Classe(String nome, int hp, int mp, int forza, int intelligenza, int destrezza, int fortuna, int agilita, int difesa, int arcano, int iniziativa) {
        this.nome = nome;
        this.hp = hp;
        this.mp = mp;
        this.forza = forza;
        this.intelligenza = intelligenza;
        this.destrezza = destrezza;
        this.fortuna = fortuna;
        this.agilita = agilita;
        this.difesa = difesa;
        this.arcano = arcano;
        this.iniziativa = iniziativa;
    }
}
import java.util.ArrayList;

public class Mondo {
    public String nome;
    public String lore;
    public ArrayList<Nemico> listaNemici;

    public Mondo(int scelta) {
        listaNemici = new ArrayList<>();

        if (scelta == 0) {
            nome = "Cimitero Dimenticato";
            lore = "Un antico cimitero dove i morti non riposano in pace. Incontrerai scheletri, zombie e il Signore dei Lich.";
            // Nemici scalari: dal più debole al più forte
            listaNemici.add(new Nemico("Scheletro Fragile", 20, 3, false));
            listaNemici.add(new Nemico("Zombie Lento", 30, 5, false));
            listaNemici.add(new Nemico("Scheletro Arciere", 45, 7, false));
            listaNemici.add(new Nemico("Ghoul Affamato", 60, 9, false));
            listaNemici.add(new Nemico("Cavaliere della Morte", 80, 12, false));
            listaNemici.add(new Nemico("Signore dei Lich (BOSS)", 150, 18, true));
        } else {
            nome = "Montagna del Drago";
            lore = "Una vetta incandescente abitata da creature del fuoco. Sopravvivi per sfidare il Drago Antico.";
            listaNemici.add(new Nemico("Cucciolo di Drago", 25, 4, false));
            listaNemici.add(new Nemico("Golem di Magma", 40, 6, false));
            listaNemici.add(new Nemico("Elementale di Fuoco", 55, 8, false));
            listaNemici.add(new Nemico("Lucertola Sputafuoco", 70, 10, false));
            listaNemici.add(new Nemico("Guerriero Draconico", 90, 14, false));
            listaNemici.add(new Nemico("Drago Antico (BOSS)", 180, 22, true));
        }
    }
}
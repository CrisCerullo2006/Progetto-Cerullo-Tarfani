public class Nemico {
    public String nome;
    public int hp;
    public int danno;
    public boolean isBoss;

    public Nemico(String nome, int hp, int danno, boolean isBoss) {
        this.nome = nome;
        this.hp = hp;
        this.danno = danno;
        this.isBoss = isBoss;
    }
}
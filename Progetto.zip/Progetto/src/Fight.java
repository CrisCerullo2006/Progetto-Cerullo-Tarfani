import java.security.SecureRandom;

class Fight {
    public static void simulateFight(Player giocatore1, Player giocatore2) {
        SecureRandom random = new SecureRandom();
        Player attaccanteCorrente = giocatore1;
        Player difensoreCorrente = giocatore2;

        System.out.println("Inizio del combattimento!");
        System.out.println(giocatore1.getNome() + " (" + giocatore1.getClasse() + ") HP: " + giocatore1.getHp());
        System.out.println(giocatore2.getNome() + " (" + giocatore2.getClasse() + ") HP: " + giocatore2.getHp());
        System.out.println();

        while (giocatore1.isAlive() && giocatore2.isAlive()) {

            int lancio = random.nextInt(20) + 1;
            int danno = 0;

            if (lancio == 1) {
                System.out.println(attaccanteCorrente.getNome() + " lancia il dado: " + lancio + " - MISS!");
            } else if (lancio == 20) {
                danno = 40;
                System.out.println(attaccanteCorrente.getNome() + " lancia il dado: " + lancio + " - CRITICAL HIT! Danno: " + danno);
            } else {
                danno = lancio;
                System.out.println(attaccanteCorrente.getNome() + " lancia il dado: " + lancio + " - Danno: " + danno);
            }


            difensoreCorrente.takeDamage(danno);
            System.out.println(difensoreCorrente.getNome() + " HP rimanenti: " + difensoreCorrente.getHp());
            System.out.println();


            if (!difensoreCorrente.isAlive()) {
                System.out.println(difensoreCorrente.getNome() + " è sconfitto! " + attaccanteCorrente.getNome() + " vince!");
                break;
            }


            Player temp = attaccanteCorrente;
            attaccanteCorrente = difensoreCorrente;
            difensoreCorrente = temp;
        }
    }
}
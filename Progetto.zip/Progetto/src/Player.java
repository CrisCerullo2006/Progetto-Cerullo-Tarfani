public class Player {
    private String nome;
    private String classe;
    private int hp;

    public Player(String nome, String classe, int hp) {
        this.nome = nome;
        this.classe = classe;
        this.hp = hp;
    }

    public String getNome() {
        return nome;
    }

    public String getClasse() {
        return classe;
    }

    public int getHp() {
        return hp;
    }

    public void takeDamage(int damage) {
        this.hp -= damage;
        if (this.hp < 0) {
            this.hp = 0;
        }
    }

    public boolean isAlive() {
        return hp > 0;
    }
}
public class Main {
    public static void main(String[] args) {

        Player player1 = new Player("Eroe", "Guerriero", 100);
        Player player2 = new Player("Nemico", "Mago", 100);


        Fight.simulateFight(player1, player2);
    }
}